<div class="container card-container"  id="feature-cards">
        <div class="row g-5 show-cards">

          <div class="col-12 col-md-4">
            <div class="card border-0 shadow p-3 h-100">
              <div class="py-3">
                <h3 class="fs-4 justify-content-center">
                  <span class="text-primary icon-hover"><i class='bx bxs-book'></i></span>
                  Онцлогууд
                </h3>
              </div>
              <p>
              Эрдмийн карьер нь санхүүгийн тогтвортой байдлыг хангахад чухал үүрэг гүйцэтгэдэг
                цөөн тооны үл хамаарах зүйлүүд. Сургууль заримтай нь шинэ нөхөрлөл бий болгох боломжийг олгодог
                ангийнхан насан туршийн хамтрагчид болж хувирдаг.</p>
            </div>
          </div>

          <div class="col-12 col-md-4">
            <div class="card border-0 shadow p-3 h-100">
              <div class="py-3">
                <h3 class="fs-4">
                  <span class="text-primary icon-hover"><i class='bx bxs-star-half'></i></i></span>
                  Амжилт
                </h3>
              </div>
              <p>
              Сургуулийн шагнал гардуулах үеэр би сурлагын амжилт, үе тэнгийн зөвлөх,
              байгаль орчны манлайлал, мэтгэлцээний ур чадвар, хөгжмийн авьяас.</p>
            </div>
          </div>

          <div class="col-12 col-md-4">
            <div class="card border-0 shadow p-3 h-100">
              <div class="py-3">
                <h3 class="fs-4">
                  <span class="text-primary icon-hover"><i class='bx bxs-cuboid'></i></span>
                  Зорилго
                </h3>
              </div>
              <p>Сониуч зан, хамтын ажиллагаа, инноваци хөгжих орчинг бүрдүүлэх, хүмүүжүүлэх
              маргаашийн уян хатан удирдагчид.</p>
              <p> Мэдлэгийн цангааг өдөөх.</p>
            </div>
          </div>

        </div>
        <div class="row g-5 show-cards mt-3">

          <div class="col-12 col-md-4">
            <div class="card border-0 shadow p-3 h-100">
              <div class="py-3">
                <h3 class="fs-4 justify-content-center">
                  <span class="text-primary icon-hover"><i class='bx bxs-bar-chart-alt-2'></i></span>
                  Тогтвортой хөгжил
                </h3>
              </div>
              <p>
              Шилдэг байдал бол өөрийгөө зориулах, тууштай байх, тууштай байхын оргил юм.
              тасралтгүй сайжруулах, бүх хүчин чармайлтад агуу байдлын стандартыг тогтоох.</p>
            </div>
          </div>

          <div class="col-12 col-md-4">
            <div class="card border-0 shadow p-3 h-100">
              <div class="py-3">
                <h3 class="fs-4">
                  <span class="text-primary icon-hover"><i class='bx bxs-user-badge'></i></span>
                  Эрх мэдэл
                </h3>
              </div>
              <p>
              Эрх мэдэл нь хувь хүний ​​доторх хязгааргүй боломжийг нээж, боломжийг олгодог түлхүүр юм
              Тэд өөрсдийн хүч чадлаа хүлээн зөвшөөрч, сорилт бэрхшээлийг өөртөө итгэлтэйгээр даван туулах болно.</p>
            </div>
          </div>

          <div class="col-12 col-md-4">
            <div class="card border-0 shadow p-3 h-100">
              <div class="py-3">
                <h3 class="fs-4">
                  <span class="text-primary icon-hover"><i class='bx bxs-extension'></i></span>
                  Бүтээлч байдал
                </h3>
              </div>
              <p>Бүтээлч байдал бол санаануудаар амьсгалж, шинэ замыг гэрэлтүүлдэг эрч хүчтэй хүч юм
              хязгааргүй шинэлэг санаа, төсөөллөөр дэлхийг дүрслэх.</p>
            </div>
          </div>

        </div>

      </div>