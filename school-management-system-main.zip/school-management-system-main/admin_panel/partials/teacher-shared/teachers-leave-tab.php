<div class="teachers-leave">
	<div class="row pb-10 teacher-leave-insights mt-1 g-4">
		<div class="col-xl-3 col-lg-3 col-md-6 mb-20">

			<div class="card mb-3 shadow h-100 total-staff-insight" style="max-width: 540px;">
				<div class="row g-0">
					<div class="col-4">
						<div class="side-icon">
							<i class='bx bxs-user-account '></i>

						</div>
					</div>
					<div class="col-8">
						<div class="card-body">
							<h5 class="card-title" id="total-teacher-number">_ _ _ _</h5>
							<h6 class="card-title">Нийт багш нар</h6>

						</div>
					</div>
				</div>
			</div>

		</div>
		<div class="col-xl-3 col-lg-3 col-md-6 mb-20">
			<div class="card mb-3 shadow h-100 approved-insight" style="max-width: 540px;">
				<div class="row g-0">
					<div class="col-4">
						<div class="side-icon">
							<i class='bx bxs-hourglass-bottom'></i>

						</div>
					</div>
					<div class="col-8">
						<div class="card-body">
							<h5 class="card-title" id="approved-leave-number">_ _ _ _</h5>
							<h6 class="card-title">Зөвшөөрөгдсөн чөлөө</h6>

						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-3 col-lg-3 col-md-6 mb-20">
			<div class="card mb-3 shadow h-100 pending-insight" style="max-width: 540px;">
				<div class="row g-0">
					<div class="col-4">
						<div class="side-icon">
							<i class='bx bxs-hourglass'></i>

						</div>
					</div>
					<div class="col-8">
						<div class="card-body">
							<h5 class="card-title" id="pending-leave-number">_ _ _ _</h5>
							<h6 class="card-title">Хүлээгдэж буй чөлөө</h6>

						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-3 col-lg-3 col-md-6 mb-20">
			<div class="card mb-3 shadow h-100 rejected-insight" style="max-width: 540px;">
				<div class="row g-0">
					<div class="col-4">
						<div class="side-icon">

							<i class='bx bx-hourglass'></i>
						</div>
					</div>
					<div class="col-8">
						<div class="card-body">
							<h5 class="card-title" id="rejected-leave-number">_ _ _ _</h5>
							<h6 class="card-title">Татгалзсан чөлөө</h6>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="container mt-5">

		<ul class="nav nav-pills">

			<li class="nav-item">
				<span class="nav-link me-2 active cursor-pointer" id="pending-leave-tab" onclick="tabButtonClicked('pending')">Хүлээгдэж буй бүлэг</span>
			</li>
			<li class="nav-item me-2">
				<span class="nav-link cursor-pointer " id="approved-leave-tab" onclick="tabButtonClicked('approved')">Зөвшөөрөгдсөн чөлөө</span>
			</li>
			<li class="nav-item">
				<span class="nav-link me-2 cursor-pointer" id="rejected-leave-tab" onclick="tabButtonClicked('rejected')">Татгалзсан чөлөө</span>
			</li>

		</ul>

		<div class="card my-3 border-0 leave-list-box">

			<table>
				<thead>
					<tr>
						<th class="fs-6 text-center pt-3">АЖИЛТНЫ НЭР</th>
						<th class="fs-6 text-center pt-3">ТӨРЛИЙГ ҮЛДЭЭ</th>
						<th class="fs-6 text-center pt-3">ХЭРЭГЛЭХ огноо</th>
						<th class="fs-6 text-center pt-3">огнооны хүрээ</th>
						<th class="fs-6 text-center pt-3">ҮЙЛ АЖИЛЛАГАА</th>
					</tr>
				</thead>
				<tbody id="leaves-table">

					<tr>
						<td class="text-center">Youmi</td>
						<td class="text-center">Эмнэлгийн чөлөө</td>
						<td class="text-center">12 march 2024</td>
						<td class="text-center">12 march 2024 - 14 march 2024</td>
						<td class="content-center">
							<div class="d-flex small-flex-column">
								<span data-bs-toggle="modal" data-bs-target="#view-leave-modal">
									<button class="btn btn-warning me-1 btn-sm border-0 d-flex justify-content-center text-center" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-custom-class="custom-tooltip" data-bs-title="View Details">
										<i class='bx bx-show-alt'></i>
									</button>
								</span>
								<button class="btn btn-success me-1 btn-sm border-0 d-flex justify-content-center text-center">
									<i class='bx bx-dots-horizontal'></i>
								</button>
							</div>

						</td>
					</tr>
					<tr>
						<td class="text-center">Selmee</td>
						<td class="text-center">Jawhaa</td>
						<td class="text-center">Gambaa</td>
						<td class="text-center">@fat</td>
						<td class="content-center">
							<div class="d-flex small-flex-column">
								<span data-bs-toggle="modal" data-bs-target="#view-leave-modal">
									<button class="btn btn-warning me-1 btn-sm border-0 d-flex justify-content-center text-center" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-custom-class="custom-tooltip" data-bs-title="View Details">
										<i class='bx bx-show-alt'></i>
									</button>
								</span>
								<button class="btn btn-success me-1 btn-sm border-0 d-flex justify-content-center text-center" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-custom-class="custom-tooltip" data-bs-title="Approve Leave">
									<i class='bx bx-check'></i>
								</button>
								<button class="btn btn-danger me-1 btn-sm border-0 d-flex justify-content-center text-center" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-custom-class="custom-tooltip" data-bs-title="Reject Leave">
									<i class='bx bx-x'></i>
								</button>
							</div>
						</td>
					</tr>
					<tr>
						<td class="text-center">jhjs</td>
						<td class="text-center">jkds/td>
						<td class="text-center">@twitter</td>
						<td class="text-center">@facebook</td>
						<td class="content-center">
							<div class="d-flex small-flex-column">
								<span data-bs-toggle="modal" data-bs-target="#view-leave-modal">
									<button class="btn btn-warning me-1 btn-sm border-0 d-flex justify-content-center text-center" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-custom-class="custom-tooltip" data-bs-title="View Details">
										<i class='bx bx-show-alt'></i>
									</button>
								</span>
								<button class="btn btn-danger me-1 btn-sm border-0 d-flex justify-content-center text-center" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-custom-class="custom-tooltip" data-bs-title="Delete">
									<i class='bx bxs-trash'></i>
								</button>
							</div>
						</td>
					</tr>
				</tbody>
			</table>

		</div>

		<div class="dataNotAvailable" id="NoLeavesAvailable">
			<div class="_flex-container box-hide">
				<div class="no-data-box">
					<div class="no-dataicon">
						<i class='bx bxs-file'></i>
					</div>
					<p>чөлөө байхгүй</p>
				</div>
			</div>
		</div>

		<hr class="text-danger">

		<div id="leave-pagination">
			<div class="d-grid gap-2 d-md-flex justify-content-md-end">
				<div class="btn-group" role="group" aria-label="Basic example">
					<button type="button" class="btn btn-secondary" id="leave-prev-btn">өмнөх</button>
					<a class="btn btn-secondary disabled" role="button" aria-disabled="true" id="leave-page-number">1</a>
					<button type="button" class="btn btn-secondary" id="leave-next-btn">дараагийн</button>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- start view model -->


<div class="modal fade view-leave-modal" id="view-leave-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content" id="view-modal-content" style="display: none;">
			
		</div>
		<div class="modal-content" id="no-data-view-modal-content">
			<div class="modal-header">

				<h1 class="modal-title fs-5" id="staticBackdropLabel" id="teacher_name">
				Хүлээгээрэй
				</h1>
				<button type="button" class="close mr-2" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-x'></i></button>
			</div>
			<div class="modal-body px-3">

				<div class="dataNotAvailable"  style="display:block;">
					<div class="_flex-container box-hide">
						<div class="no-data-box">
							<div class="no-dataicon">
							<i class='bx bxs-hourglass'></i>
							</div>
							<p>Хүлээгээрэй</p>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">

				<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Хаах</button>

			</div>
		</div>
	</div>
</div>


<div class="modal fade" id="approved-confirmation-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog  modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
			</div>
			<div class="modal-body">
				<strong>Та энэ чөлөөг зөвшөөрөхийг хүсэж байна уу?</strong>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Хаах</button>
				<button type="button" class="btn btn-success" onclick="changeStatusOfLeave()">Зөвшөөрөх</button>
			</div>
		</div>
	</div>
</div>


<div class="modal fade" id="reject-confirmation-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog  modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
			</div>
			<div class="modal-body">
				<strong>Та үнэхээр энэ чөлөөнөөс татгалзахыг хүсч байна уу?</strong>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Хаах</button>
				<button type="button" class="btn btn-danger" onclick="changeStatusOfLeave()">Татгалзах</button>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="delete-leave-confirmation-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog  modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
			</div>
			<div class="modal-body">
				<strong>Та үнэхээр энэ чөлөөг устгахыг хүсэж байна уу?</strong>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Хаах</button>
				<button type="button" class="btn btn-danger" onclick="deleteLeave()">Устгах</button>
			</div>
		</div>
	</div>
</div>
<!-- end view model -->