
<div class="sidebar">
    <a href="dashboard.php" class="logo">
        <!-- <i class='bx bx-book-bookmark'></i> -->
        <img src="../images/book1.jpg">
          
    </a>
    
      <ul class="side-menu-opener">
        <!-- <li>
            <div class='open-arrow SidebarOpener'><i class='bx bxs-chevron-right'></i></div>
        </li> -->
    </ul>
    
    <ul class="side-menu main-side-board">
        <li><a href="dashboard.php"><i class='bx bxs-dashboard'></i>Хяналтын самбар</a></li>
        <li><a href="teacher.php"><i class='bx bxs-user-rectangle'></i>Багш</a></li>
        <li><a href="student.php"><i class='bx bxs-user-detail'></i>Сурагч</a></li>
        <li><a href="subjects.php"><i class='bx bx-book-bookmark'></i>Сэдвүүд</a></li>
        <li><a href="attendence.php"><i class='bx bx-list-check'></i>Ирц</a></li>
        <li><a href="noticeboard.php"><i class='bx bx-bookmark'></i>Мэдээллийн самбар</a></li>
        <li><a href="timetable.php"><i class='bx bx-table'></i>Цагийн хүснэгт</a></li>
        <li><a href="syllabus.php"><i class='bx bx-file-blank'></i>Хичээлийн хөтөлбөр</a></li>
        <li><a href="notes.php"><i class='bx bx-note'></i>Гэрийн даалгавар</a></li>
        <li><a href="marks.php"><i class='bx bx-paste'></i>Дүн</a></li>
        <li><a href="buses.php"><i class='bx bxs-bus'></i>Автобусны үйлчилгээ</a></li>
        <li><a href="settings.php"><i class='bx bx-cog'></i>Тохиргоо</a></li>
    </ul>
    <ul class="side-menu">
        <li>
            <a class="logout" data-bs-toggle="modal" data-bs-target="#logout-modal">
                <i class='bx bx-log-out-circle'></i>
                Гарах
            </a>
        </li>
    </ul>
</div>

<div class="modal fade" id="logout-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
            </div>
            <div class="modal-body">
                <strong>Та үнэхээр гармаар байна уу?</strong>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Хаах</button>
                <button type="button" class="btn btn-danger" onclick="logout()">Гарах</button>
            </div>
        </div>
    </div>
</div>
